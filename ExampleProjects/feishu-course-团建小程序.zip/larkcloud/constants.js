module.exports = {
  APP_ID: larkcloud.env.APP_ID,
  APP_SECRET: larkcloud.env.APP_SECRET,
  ACCESS_TOKEN_KEY: 'lark_access_token',
  ACCESS_TOKEN_EXPIRE: 3600,
  CUSTOM_SESSION_EXPIRE: 2 * 24 * 60 * 60
}
