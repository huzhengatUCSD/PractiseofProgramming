package chatroom;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.net.*;
import java.sql.*;

public class Register extends JFrame{
	private JPasswordField pwd1;
	private JPasswordField pwd2;
	private JTextField name;
	private JRadioButton sex1;
	private JRadioButton sex2;
	private JButton ok;
	private JButton reset;
	public Register(){
		this.init();
		this.setVisible(true);
	}
	private boolean napwd(String mingzi,String mima){
		String user="root";
		String pwd="mysql";
		//此处略去数据库连接和验证，以mockup为主
		/*String myjdbc="jdbc:mysql://localhost:3306/userinfo?characterEncoding=utf8&useSSL=true";
		try{Class.forName("com.mysql.jdbc.Driver");
		String sqlstr="select * from info";
		Connection con=DriverManager.getConnection(myjdbc,user,pwd);
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(sqlstr);
		while(rs.next()){
			if(rs.getString(1).equals(mingzi)&&rs.getString(2).equals(mima)){
				JOptionPane.showMessageDialog(null,"该账号已被注册！！");
				return true;
			}
		}
		jdbcutils.close(stmt,con);
		
				}catch(Exception el){
			el.printStackTrace();
		}*/
		return true;
	}
	public void init(){
		this.setTitle("注册新账号");
		this.setLocation(300, 200);
		this.setSize(800, 300);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		this.setResizable(false);
		JLabel label=new JLabel("昵称：");
		label.setBounds(29,37,60,17);
		getContentPane().add(label);
		name=new JTextField();
		name.setBounds(125, 34, 194, 22);
		getContentPane().add(name);
		JLabel label2=new JLabel("密码：");
		label2.setBounds(29, 72, 60, 17);
		getContentPane().add(label2);
		JLabel label3=new JLabel("确认密码：");
		label3.setBounds(24, 107, 98, 17);
		getContentPane().add(label3);
		pwd1=new JPasswordField();
		pwd1.setBounds(125, 70, 157, 22);
		getContentPane().add(pwd1);
		pwd2=new JPasswordField();
		pwd2.setBounds(125, 105, 157, 22);
		getContentPane().add(pwd2);
		JLabel label4=new JLabel("性别：");
		label4.setBounds(347,23,71,42);
		getContentPane().add(label4);
		sex1=new JRadioButton("男",true);
		sex1.setBounds(429, 32, 71, 25);
		getContentPane().add(sex1);
		sex2=new JRadioButton("女");
		sex2.setBounds(507, 32, 77, 25);
		getContentPane().add(sex2);
		ButtonGroup group=new ButtonGroup();
		group.add(sex1);
		group.add(sex2);
		ok=new JButton("确认");
		ok.setBounds(117, 192, 71, 53);
		getContentPane().add(ok);
		reset=new JButton("清空");
		reset.setBounds(347,192, 71, 53);
		getContentPane().add(reset);
		
		reset.addActionListener(new ActionListener(){
			public void actionPerformed(final ActionEvent e){
				name.setText("");
				pwd1.setText("");
				pwd2.setText("");
				name.requestFocusInWindow();	
			}
		});
		ok.addActionListener(new ActionListener(){
			public void actionPerformed(final ActionEvent e){
				if(pwd1.getPassword().length==0||
						pwd2.getPassword().length==0){
					JOptionPane.showMessageDialog(Register.this,"必须输入密码！！");
				}
				else if(!new String(pwd1.getPassword()).equals(new String(pwd2.getPassword()))){
					JOptionPane.showMessageDialog(Register.this,"两次输入密码不一致！！");
					pwd1.setText("");
					pwd2.setText("");
					pwd1.requestFocusInWindow();
				}
				else if(!napwd(name.getText(),new String(pwd1.getPassword()))){
					/*String user="root";
					String pwd="mysql";
					String myjdbc="jdbc:mysql://localhost:3306/userinfo?characterEncoding=utf8&useSSL=true";
					try{Class.forName("com.mysql.jdbc.Driver");
					String Name=name.getText();
					String Pwd=new String(pwd1.getPassword());
					int temp=sex1.isSelected()?1:0;
					String sqlstr="insert into info(name,pwd,sex) values(?,?,?)";
					Connection con=DriverManager.getConnection(myjdbc,user,pwd);
					PreparedStatement psmt=con.prepareStatement(sqlstr);
					psmt.setString(1, Name);
					psmt.setString(2, Pwd);
					psmt.setInt(3, temp);
					psmt.executeUpdate();
					jdbcutils.close(psmt,con);
					
					Thread login = new LoginThread();
					login.start();
					}catch(Exception el){
						el.printStackTrace();
					}*/
				
				}
			}
		});
		
		
	}

}
