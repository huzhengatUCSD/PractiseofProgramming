package chatroom;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.*;
import java.net.Socket;
import javax.swing.*;
import javax.swing.border.TitledBorder;

import java.sql.*;

public class LoginThread extends Thread implements Protocol {
	private JFrame loginf;

	private JTextField t;

	public void run() {
		/*
		 * 设置登录界面
		 */
		loginf = new JFrame();
		loginf.setResizable(true);
		loginf.getContentPane().setLayout(null);
		ImageIcon imageIcon = new ImageIcon("image/login.png"); 
		loginf.setIconImage(imageIcon.getImage());
		int x = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int y = (int)Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		loginf.setLocation((x-loginf.getWidth())/2, (y-loginf.getHeight())/2);
		loginf.setSize(385,326);
		loginf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		loginf.setTitle(SOFTWARE + " - 登录");
		System.out.println(new File("image/logo.png").getAbsolutePath());
		Icon icon = new ImageIcon("image/logo.png");
		JLabel label = new JLabel(icon);
		label.setLocation(2, 0);
		label.setSize(new Dimension(372, 120));
		loginf.getContentPane().add(label, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("CheckBoxMenuItem.border"), "\u6B22\u8FCE\u767B\u5F55", TitledBorder.CENTER, TitledBorder.TOP, null, Color.BLUE)); //欢迎登录
		panel.setBounds(0, 126, 379, 171);
		loginf.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u8D26\u6237\u540D:");//用户名
		lblNewLabel.setBounds(54, 41, 45, 29);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u5BC6\u7801:"); //密码
		lblNewLabel_1.setBounds(54, 80, 54, 24);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(118, 45, 104, 21);
		textField.requestFocusInWindow();
		panel.add(textField);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(118, 82, 104, 21);
		panel.add(passwordField);
		
		JButton btnNewButton_1 = new JButton("\u767B\u5F55"); //登录
		btnNewButton_1.setToolTipText("enter");
		btnNewButton_1.setBounds(188, 123, 93, 23);
		panel.add(btnNewButton_1);
		
		//登录按钮添加事件
		
		class ButtonListener implements ActionListener {
			private Socket s;
			public void actionPerformed(ActionEvent e) {
				//判断账户名密码是否为空
				if(textField.getText().length()==0 || passwordField.getPassword().length==0){
					JOptionPane.showMessageDialog(loginf, "账号或密码不能为空", "请输入账户名或密码", JOptionPane.ERROR_MESSAGE);
					textField.requestFocusInWindow();
					return;
				}
				if (checkName(textField.getText())&&napwd(textField.getText(),new String(passwordField.getPassword()))) {
					try {
						s = new Socket(DEFAULT_IP, DEFAULT_PORT);
						/*
						 * 连接服务器
						 */
						try {
							InputStream is = s.getInputStream();
							InputStreamReader ir = new InputStreamReader(is,
									"GBK");
							// java.nio.charset.Charset.defaultCharset());  //java新IO
							BufferedReader in = new BufferedReader(ir);
							OutputStream os = s.getOutputStream();
							OutputStreamWriter or = new OutputStreamWriter(os,
									"GBK");
							PrintWriter out = new PrintWriter(or);
							out.println(VERSION);
							out.flush();
							out.println(textField.getText());
							out.flush();
							String ver;
							if (!(ver = in.readLine()).equals(VERSION)) {
								throw new VersionException(ver);
							}
							if (in.readLine().equals(USER_EXIST)) {
								throw new ExistException();
							}
							/*
							 * 启动聊天线程
							 */
							Thread chat = new ChatThread(textField.getText(),
									s, in, out);
							loginf.setVisible(false);
							loginf.setEnabled(false);
							chat.start();
						} catch (IOException e1) {// 流操作异常
							t.setText("通讯失败,请重试!");
							try {
								s.close();
							} catch (IOException e2) {
							}
						} catch (VersionException e3) {// 用户存在异常(接口中定义)
							t.setText(e3.getMessage());
							try {
								s.close();
							} catch (IOException e4) {
							}
						} catch (ExistException e5) {// 用户存在异常(接口中定义)
							t.setText(e5.getMessage());
							try {
								s.close();
							} catch (IOException e6) {
							}
						}
					} catch (IOException e7) {// Socket连接服务器异常
						t.setText("连接服务器失败,请重试!");
					}
				}
			}

		}	

		ButtonListener bl = new ButtonListener();
		btnNewButton_1.addActionListener(bl);
		textField.addActionListener(bl);
		
		t = new JTextField("Version " + VERSION + "  by 孙铮");
		t.setHorizontalAlignment(JTextField.CENTER);
		t.setEditable(false);
		loginf.getContentPane().add(t, BorderLayout.SOUTH);

		loginf.setVisible(true);	
	}

	/**
	 * 判断登录名是否有效
	 * @wbp.parser.entryPoint
	 */
	private boolean checkName(String name) {
		if (name.length() < NAME_MIN) {
			t.setText("错误:登录名不能小于" + NAME_MIN + "字符");
			return false;
		}
		if (name.length() > NAME_MAX) {
			t.setText("错误:登录名不能大于" + NAME_MAX + "字符");
			return false;
		}
		if (name.indexOf(" ") > -1) {
			t.setText("错误:登录名不能包含空格");
			return false;
		}
		for (int i = 0; i < FORBID_WORDS.length; i++) {
			if (name.indexOf(FORBID_WORDS[i]) > -1) {
				t.setText("错误:登录名不能包含敏感信息");
				return false;
			}
		}
		return true;
	}
	private boolean napwd(String mingzi,String mima){
		/*String user="root";
		String pwd="mysql";
		String myjdbc="jdbc:mysql://localhost:3306/userinfo?characterEncoding=utf8&useSSL=true";
		try{Class.forName("com.mysql.jdbc.Driver");
		String sqlstr="select * from info";
		Connection con=DriverManager.getConnection(myjdbc,user,pwd);
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery(sqlstr);
		while(rs.next()){
			if(rs.getString(1).equals(mingzi)&&rs.getString(2).equals(mima)){
				return true;
			}
		}
		JOptionPane.showMessageDialog(null,"登录名或密码错误！！");
		jdbcutils.close(stmt,con);
		
				}catch(Exception el){
			el.printStackTrace();
		}*/
		return true;
	}
	
	private static final long serialVersionUID = 8253492631016343272L;
	private JTextField textField;
	private JPasswordField passwordField;
}
